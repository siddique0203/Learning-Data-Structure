#include <iostream>
using namespace std;

    int main() {
    int Array_1[] = {1, 4, 6, 3, 4, 9};
    int size_1 = sizeof(Array_1) / 4;

    int Array_2[] = {5, 3, 7, 1, 2, 6};
    int size_2 = sizeof(Array_2) / 4;

    bool foundCommon = false;


    for (int i = 0; i < size_1; i++) {
    for (int j = 0; j < size_2; j++) {
    if (Array_1[i] == Array_2[j]) {
    cout << Array_1[i] << " ";
    foundCommon = true;
    break;
    }
    }
   }

    if (!foundCommon) {
    cout << "No common element!";
 }

return 0;
}
