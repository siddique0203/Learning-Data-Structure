#include <iostream>
using namespace std;

    int main()
    {
    int Array_1[10] = {8, 4, 6, 1, 6, 9, 6, 1, 9, 8};
    int size = sizeof(Array_1) / 4;

    for (int i = 0; i < size; i++) {
    int count = 1;

    bool alreadyCounted = false;


    for (int j = 0; j < i; j++) {
    if (Array_1[i] == Array_1[j]) {
    alreadyCounted = true;
    break;
    }
    }


    if (!alreadyCounted) {
    for (int j = i + 1; j < size; j++) {
    if (Array_1[i] == Array_1[j]) {
    count++;
    }
    }
     cout << Array_1[i] << " occurs = " << count << " time " <<  endl;
    }
  }


}
