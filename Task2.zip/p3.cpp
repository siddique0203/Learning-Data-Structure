#include<iostream>

using namespace std;
int main(){

  int arr[]={1,4,6,3,6,9,1};

   bool foundCommon = false;


    for (int i = 0; i < sizeof(arr)/4; i++) {
    for (int j = 0; j < sizeof(arr)/4; j++) {
    if (arr [i] == arr [j]) {

    foundCommon = true;

    break;
    }if(foundCommon==false){cout << arr [i] << " ";}
    }
   }

    if (!foundCommon) {
    cout << "Array already unique!";
 }
}
