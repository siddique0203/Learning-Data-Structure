#include<iostream>

using namespace std;
int main(){

    int arr[10]={8,4,6,1,6,9,6,1,9,8};
    int n;
    cout<<"input a number to search: ";
    cin>>n;

    int count=0;

    for(int i=0; i<10; i++){
        if(arr[i]==n){
            count++;
        }
    }

    cout<<"The number occurs "<<count <<" times in the array";


}
