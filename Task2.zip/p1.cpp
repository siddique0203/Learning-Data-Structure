#include<iostream>

using namespace std;
int main(){
     int array1[]={10,20,30,40,50};
    int size=sizeof(array1)/4;
    for(int i=0; i<size/2; i++){
        int temp=array1[i];
        array1[i]=array1[size-1-i];
        array1[size-1-i]=temp;
    }





     int array2[] = {1, 2, 3, 4, 5, 6, 7, 8};
     int size2 = sizeof(array2) / 4;


     for (int i = 0; i < size2 / 2; i++) {
      int temp2 = array2[i];
      array2[i] = array2[size2 - 1 - i];
      array2[size2 - 1 - i] = temp2;
      }


      for (int i = 0; i < size2; i++) {
       cout << array2[i] << " ";
       }
       for(int i=0; i<size; i++){
        cout<<array1[i]<<" ";
    }


}
